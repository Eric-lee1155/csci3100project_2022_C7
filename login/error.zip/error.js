// import {React} from 'react';
// const React = require('react');
// import {ReactDOM} from 'react-dom';
// const ReactDOM = require('react-dom');



// const [state,setState] = React.useState(0);
// var state=0;

// const JsContent =()=>{
//     return(
//         <>
            
//             <h2>Something get wrong.....</h2>
//             {/* <button  onClick={(bruh())} >New Player?</button> */}
//         </>
//     )
// }

function JsContent() {
    return(
        <>
            <br></br>
            <h2>Something get wrong.....</h2>
            <button  onClick={(bruh())} >New Player?</button>
        </>
    )
}

function bruh(){
    fetch("http://119.246.79.200:8080/login", {
        method:'POST',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
            // 'Access-Control-Allow-Origin': '*',
            // 'mode' : 'no-cors'
        },
        body: new URLSearchParams({
            'email': "fail"
        }
        )
        })
}


// function login(){

//     const [AC, SetAC] = React.useState("");

//     const handleChange = (event)=>{
//         const name = event.target.name;
//         const value = event.target.value;
//         SetAC(values => ({...values,[name]:value}))
//     }
    
//     const handleSubmit = (event) => {
//         event.preventDefault();
//         console.log(AC);
//         if(AC.userName=="Moskva" && AC.password=="Putin"){
//             //window.location.assign("./sucess")
//             console.log("Y");
//             // setState(1);
            
//         }        
//         else 
//         {
//             console.log("N");
//             // setState(2);
//             console.log(state);
            
//         }
//     }
    
//     return <>
//         <form onSubmit={handleSubmit}> 
//             <label>Enter your name:<br></br>
//             <input 
//                 type="text" 
//                 name="userName"
//                 value={AC.userName || ""}
//                 onChange={handleChange}
//             />
//             <br></br>
//             </label>
//             <label>Enter your password:<br></br>
//             <input 
//                 type="password" 
//                 name="password"
//                 value={AC.password || ""}
//                 onChange={handleChange}
//             /><br></br>
//             </label>
//             <input type="submit" />
//         </form>
        
//     </>
// }



// const notfound = () =>{
//     return(
//         <p>404 not found!</p>
//     )
// }

// const sucess = () =>{
//     return (
//     <>
//     <h1>Login Sucess!</h1>
//     <h2>Wellcome to this game!</h2>
//     <h3>You will be redirected soon.</h3>
//     </>
//     )
// }

// const fail = () =>{
//     return (
//     <>
//     <h1>Login Fail!</h1>
//     <h2>Please log in again.</h2>
//     <h3>You will be redirected soon.</h3>
//     </>
//     )
// }



ReactDOM.render(<JsContent/>, document.getElementById('Content'));